"""
Logging Service — Centralized logging with per-depot log files.
Creates logs/<depot_name>_<timestamp>.log for depot-specific output.
"""

import logging
from datetime import datetime
from pathlib import Path

# ---------------------------------------------------
# Project Root
# ---------------------------------------------------

_PROJECT_ROOT = Path(__file__).resolve().parent.parent
_LOGS_DIR = _PROJECT_ROOT / "logs"

# ---------------------------------------------------
# Logging Format
# ---------------------------------------------------

_DEFAULT_FORMAT = "%(asctime)s - %(levelname)s - %(message)s"
_DEFAULT_DATE_FORMAT = "%Y-%m-%d %H:%M:%S"

_ROOT_LOGGER_NAME = "backend_automation"

# Track created loggers
_loggers: dict[str, logging.Logger] = {}

# Track log paths
_logger_paths: dict[str, Path] = {}


# ---------------------------------------------------
# Ensure logs directory
# ---------------------------------------------------

def _ensure_logs_dir() -> Path:
    _LOGS_DIR.mkdir(parents=True, exist_ok=True)
    return _LOGS_DIR


# ---------------------------------------------------
# Generate log filename
# ---------------------------------------------------

def _make_log_filename(depot_name: str | None) -> str:
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    prefix = depot_name.lower() if depot_name else "app"
    return f"{prefix}_{timestamp}.log"


# ---------------------------------------------------
# Main Logger Factory
# ---------------------------------------------------

def get_logger(
    depot_name: str | None = None,
    level: int = logging.INFO,
    console: bool = True,
) -> logging.Logger:

    logger_key = (depot_name or "app").lower()

    # Return existing logger if already created
    if logger_key in _loggers:
        return _loggers[logger_key]

    logs_dir = _ensure_logs_dir()
    log_filename = _make_log_filename(depot_name)
    log_path = logs_dir / log_filename

    logger_name = f"{_ROOT_LOGGER_NAME}.{logger_key}"
    logger = logging.getLogger(logger_name)

    logger.setLevel(level)
    logger.propagate = False  # prevents duplicate logs with uvicorn

    # ---------------------------------------------------
    # File Handler
    # ---------------------------------------------------

    file_handler = logging.FileHandler(log_path, encoding="utf-8")
    file_handler.setLevel(level)
    file_handler.setFormatter(
        logging.Formatter(_DEFAULT_FORMAT, datefmt=_DEFAULT_DATE_FORMAT)
    )

    logger.addHandler(file_handler)

    # Save path
    _logger_paths[logger_key.upper()] = log_path

    # ---------------------------------------------------
    # Console Handler
    # ---------------------------------------------------

    if console:
        console_handler = logging.StreamHandler()
        console_handler.setLevel(level)
        console_handler.setFormatter(
            logging.Formatter(_DEFAULT_FORMAT, datefmt=_DEFAULT_DATE_FORMAT)
        )
        logger.addHandler(console_handler)

    # Save logger
    _loggers[logger_key] = logger

    return logger


# ---------------------------------------------------
# Get Log File Path
# ---------------------------------------------------

def get_log_path(depot_name: str | None = None) -> Path:

    depot_key = (depot_name or "app").upper()

    if depot_key in _logger_paths:
        return _logger_paths[depot_key]

    logs_dir = _ensure_logs_dir()
    return logs_dir / _make_log_filename(depot_name)
